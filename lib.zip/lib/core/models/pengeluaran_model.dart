// model untuk pengeluaran
class PengeluaranModel {
  String docId = ''; // ID dokumen Firestore
  String namaPengeluaran, kategoriPengeluaran, buktiPengeluaran;
  String verifikatorId; // **DIREVISI:** Relasi ke UserModel.id
  double jumlahPengeluaran;
  DateTime tanggalPengeluaran, tanggalTerverifikasi;

  PengeluaranModel({
    required this.docId,
    required this.namaPengeluaran,
    required this.kategoriPengeluaran,
    required this.verifikatorId,
    required this.buktiPengeluaran,
    required this.jumlahPengeluaran,
    required this.tanggalPengeluaran,
    required this.tanggalTerverifikasi,
  });

  // konversi dari map ke object
  factory PengeluaranModel.fromMap(Map<String, dynamic> map, String docId) {
    return PengeluaranModel(
      docId: map['docId'],
      namaPengeluaran: map['nama_pengeluaran'],
      jumlahPengeluaran: map['jumlah_pengeluaran'] is int
          ? (map['jumlah_pengeluaran'] as int).toDouble()
          : map['jumlah_pengeluaran'],
      tanggalPengeluaran: DateTime.parse(map['tanggal_pengeluaran']),
      kategoriPengeluaran: map['kategori_pengeluaran'],
      verifikatorId: map['verifikator_id'], // Menggunakan verifikator_id
      buktiPengeluaran: map['buktiPengeluaran'],
      tanggalTerverifikasi: DateTime.parse(map['tanggal_terverifikasi']),
    );
  }

  // konversi dari object ke map
  Map<String, dynamic> toMap() {
    return {
      'docId': docId,
      'nama_pengeluaran': namaPengeluaran,
      'kategori_pengeluaran': kategoriPengeluaran,
      'verifikator_id': verifikatorId, // Menggunakan verifikator_id
      'buktiPengeluaran': buktiPengeluaran,
      'jumlah_pengeluaran': jumlahPengeluaran,
      'tanggal_pengeluaran': tanggalPengeluaran.toIso8601String(),
      'tanggal_terverifikasi': tanggalTerverifikasi.toIso8601String(),
    };
  }
}

List<PengeluaranModel> dummyPengeluaran = [
  PengeluaranModel(
    docId: 'doc1',
    namaPengeluaran: 'Pembelian ATK Kantor',
    kategoriPengeluaran: 'Operasional',
    verifikatorId: '201', // ID Andi Wijaya
    buktiPengeluaran: 'bukti_atk.jpg',
    jumlahPengeluaran: 350000.0,
    tanggalPengeluaran: DateTime(2025, 1, 12),
    tanggalTerverifikasi: DateTime(2025, 1, 13),
  ),
  PengeluaranModel(
    docId: 'doc2',
    namaPengeluaran: 'Listrik Bulanan',
    kategoriPengeluaran: 'Tagihan',
    verifikatorId: '202', // ID Sinta Dewi
    buktiPengeluaran: 'bukti_listrik.pdf',
    jumlahPengeluaran: 1250000.0,
    tanggalPengeluaran: DateTime(2025, 1, 15),
    tanggalTerverifikasi: DateTime(2025, 1, 16),
  ),
  PengeluaranModel(
    docId: 'doc3',
    namaPengeluaran: 'Pembelian Bahan Konsumsi',
    kategoriPengeluaran: 'Konsumsi',
    verifikatorId: '103', // ID Budi Santoso
    buktiPengeluaran: 'bukti_konsumsi.jpg',
    jumlahPengeluaran: 785000.0,
    tanggalPengeluaran: DateTime(2025, 2, 1),
    tanggalTerverifikasi: DateTime(2025, 2, 2),
  ),
  PengeluaranModel(
    docId: 'doc4',
    namaPengeluaran: 'Maintenance Server',
    kategoriPengeluaran: 'Teknologi',
    verifikatorId: '203', // ID Rizky Maulana
    buktiPengeluaran: 'bukti_server.pdf',
    jumlahPengeluaran: 2500000.0,
    tanggalPengeluaran: DateTime(2025, 2, 10),
    tanggalTerverifikasi: DateTime(2025, 2, 12),
  ),
  PengeluaranModel(
    docId: 'doc5',
    namaPengeluaran: 'Perjalanan Dinas Bandung',
    kategoriPengeluaran: 'Perjalanan Dinas',
    verifikatorId: '204', // ID Dina Kartika
    buktiPengeluaran: 'bukti_perjalanan.jpg',
    jumlahPengeluaran: 3100000.0,
    tanggalPengeluaran: DateTime(2025, 3, 5),
    tanggalTerverifikasi: DateTime(2025, 3, 6),
  ),
  PengeluaranModel(
    docId: 'doc6',
    namaPengeluaran: 'Sewa Gedung Acara',
    kategoriPengeluaran: 'Event',
    verifikatorId: '205', // ID Agus Prasetyo
    buktiPengeluaran: 'bukti_sewa.pdf',
    jumlahPengeluaran: 5200000.0,
    tanggalPengeluaran: DateTime(2025, 4, 8),
    tanggalTerverifikasi: DateTime(2025, 4, 10),
  ),
  PengeluaranModel(
    docId: 'doc7',
    namaPengeluaran: 'Honor Narasumber',
    kategoriPengeluaran: 'Kegiatan',
    verifikatorId: '206', // ID Maya Putri
    buktiPengeluaran: 'bukti_honor.jpg',
    jumlahPengeluaran: 1500000.0,
    tanggalPengeluaran: DateTime(2025, 4, 20),
    tanggalTerverifikasi: DateTime(2025, 4, 21),
  ),
  PengeluaranModel(
    docId: 'doc8',
    namaPengeluaran: 'Pembelian Software Lisensi',
    kategoriPengeluaran: 'Teknologi',
    verifikatorId: '207', // ID Andri Setiawan
    buktiPengeluaran: 'bukti_lisensi.pdf',
    jumlahPengeluaran: 4600000.0,
    tanggalPengeluaran: DateTime(2025, 5, 3),
    tanggalTerverifikasi: DateTime(2025, 5, 4),
  ),
  PengeluaranModel(
    docId: 'doc9',
    namaPengeluaran: 'Cetak Brosur Promosi',
    kategoriPengeluaran: 'Marketing',
    verifikatorId: '208', // ID Tasya Amelia
    buktiPengeluaran: 'bukti_brosur.jpg',
    jumlahPengeluaran: 875000.0,
    tanggalPengeluaran: DateTime(2025, 5, 15),
    tanggalTerverifikasi: DateTime(2025, 5, 17),
  ),
  PengeluaranModel(
    docId: 'doc10',
    namaPengeluaran: 'Perawatan Kendaraan Operasional',
    kategoriPengeluaran: 'Operasional',
    verifikatorId: '209', // ID Fajar Ramadhan
    buktiPengeluaran: 'bukti_kendaraan.pdf',
    jumlahPengeluaran: 1900000.0,
    tanggalPengeluaran: DateTime(2025, 6, 1),
    tanggalTerverifikasi: DateTime(2025, 6, 2),
  ),
];
